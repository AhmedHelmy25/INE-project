# 📦 Packing Line QC Portal

**INE 311 — Quality Engineering** | Streamlit web app

A statistical quality control dashboard for high-speed dry-goods packing operations.

---

## Features

| Tab | What it does |
|-----|-------------|
| **Overview** | Portal description and quick-start guide |
| **Inputs + Simulation** | Configure process parameters, simulate weight data, download CSV |
| **Capability Analysis** | Cp, Cpk, % out-of-spec, normal distribution chart |
| **Control Charts** | X̄, R, and p-charts with automatic UCL/LCL and OOC flagging |
| **Quality Tools** | Pareto chart (editable) + sample-mean drift scatter |
| **DOE + CLT Sandbox** | Full factorial 2² DOE simulator + Central Limit Theorem demo |
| **DMAIC Tracker** | Six Sigma checklist with progress bars + exportable report |

---

## Run locally

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Deploy to Streamlit Cloud

1. Push this repo to GitHub
2. Go to [share.streamlit.io](https://share.streamlit.io)
3. Click **New app** → select your repo → set `app.py` as the entry point
4. Deploy 🚀

## Project structure

```
packing-qc-portal/
├── app.py                  # Main application
├── requirements.txt        # Python dependencies
├── .streamlit/
│   └── config.toml         # Dark theme + server config
└── README.md
```

## SPC constants used (n = 5)

| Constant | Value |
|----------|-------|
| A₂       | 0.577 |
| D₃       | 0.000 |
| D₄       | 2.114 |
| d₂       | 2.326 |
